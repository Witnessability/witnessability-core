# Evaluation Profile Amendment Record

## Amendment identifier

`PA-STATUS-HASH-BINDING-001`

## Reason

After inspection of the release materials, review identified that changing the embedded status text from RC2 to Stable would necessarily change the document hash. The initial Release Evaluation Profile did not yet require a distinct status-only Transformation Transition, a separately hashed Stable candidate, or verification that the issued publication artifact is byte-identical to that candidate.

## Governance disclosure

- The selecting party had already inspected the materials when this amendment was made.
- The same Release Evaluation Profile remained selected; no alternative profile was chosen.
- The amendment was triggered by a disclosed defect, not by an attempt to obtain a preferred evaluation outcome.
- The amendment is versioned and attributable.
- All release gates must be re-evaluated under the amended Profile.
- Ratification evaluation must occur only after the amended Profile is frozen.

## Supersession relation

| Artifact | SHA-256 | Status |
|---|---|---|
| `_archive/pre-ratification/RELEASE-EVALUATION-PROFILE-RC2.pre-status-transition.yaml` | `dfed32863eed62d50d414e6770f903cb49e72d085d3a5827b98806bbc5153afd` | Superseded for ratification |
| `RELEASE-EVALUATION-PROFILE-RC2.yaml` | `e2d5b27e0b107a1d1f800e9b66a17057075cafa5146347502a65d4b48f100958` | Amended and frozen for ratification |

## Scope of amendment

The amendment adds or strengthens only:

- explicit binding of frozen RC2 source and Stable output candidate;
- the status-block-only Transformation Transition;
- the transformation-verification gate;
- publication-artifact hash preservation;
- qualifications concerning the session-local hash statement;
- disclosure and re-evaluation requirements for this post-inspection amendment.

The conceptual Core text is unchanged.
