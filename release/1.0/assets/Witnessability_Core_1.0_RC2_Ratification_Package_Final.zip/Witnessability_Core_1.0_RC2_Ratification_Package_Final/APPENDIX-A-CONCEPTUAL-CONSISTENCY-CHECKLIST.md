# Appendix A — Conceptual Consistency Checklist

## A.1. Purpose

A claim that a specification, profile, model, or protocol binding is aligned with the Witnessability Conceptual Core is incomplete unless accompanied by an explicit **Conceptual Consistency Mapping**.

The mapping identifies:

- the text or mechanism satisfying each applicable checklist item;
- any item treated as not applicable, with justification;
- known deviations or limitations;
- the versions of the Conceptual Core, Evaluation Profile, Boundary Profile, and other material profiles used.

The checklist tests conceptual consistency. It is not by itself an implementation conformance test.

## A.2. Minimal external conceptual interface

The mapping preserves the distinction among the following six externally visible conceptual objects:

1. Target Proposition;
2. Witness Case;
3. Evaluation Profile;
4. Support Envelope;
5. Support Assessment;
6. Relying-Party Decision.

The Witness Materials set, Evidence Graph, argument structure, and Witnessability Boundary Architecture disclose the internal structure and dependencies of that interface and are not thereby demoted or made optional.

## A.3. Checklist

- **CC-1 — Typed and Scoped Target Proposition.** Defines the Target Proposition using separately represented subject, instance, semantic, polarity, modal, temporal, contextual, and normative dimensions where material.

- **CC-2 — Separation of the Minimal External Interface.** Distinguishes the Target Proposition, Witness Case, Evaluation Profile, Support Envelope, Support Assessment, and Relying-Party Decision, even when one implementation performs multiple roles.

- **CC-3 — Grounded Evidence-and-Argument Graph.** Represents premises, Witness Materials, warrants, assumptions, dependencies, defeaters, and terminal premises sufficient to reconstruct the claimed support relation.

- **CC-4 — Realization Discipline.** Does not treat intended, declared, or configured witnessing as evidence that witnessing was active or realized; assertions about realization receive their own support.

- **CC-5 — Binding Discipline.** Establishes every material subject, instance, tenant, session, epoch, environment, role, authority, policy, and Target-Proposition binding, or represents it as unknown.

- **CC-6 — Coverage and Selection Accountability.** Represents capture capability and effective coverage and distinguishes eligible, available, captured, retained, examined, presented, and Support-Basis material where material.

- **CC-7 — Provenance and Semantic Continuity.** Preserves the required production, custody, transformation, analysis, and presentation provenance, together with semantic continuity and relevant versions.

- **CC-8 — Bound Evaluation Dependencies.** Binds the Evaluation Profile and every material policy, schema, reference state, failure model, threat model, trust dependency, and effective interval to the Support Assessment.

- **CC-9 — Non-Amplification.** Ensures non-amplification and prohibits attribution of stronger or broader support without an explicit warrant and every additional premise, basis, binding, dependency, and preservation relation required by that warrant.

- **CC-10 — Uncertainty and Lifecycle Discipline.** Preserves uncertainty, counter-support, non-positive failure semantics, challenge state, lifecycle applicability, material availability, and re-evaluability without collapsing them into a binary result.

- **CC-11 — Typed Boundary Constructs.** Types every evidentially material boundary construct and identifies the preservation or non-preservation relations required across it.

- **CC-12 — Evaluation Profile Governance.** Discloses Profile authorship, authority, provenance, maintenance, effective interval, intended scope, selection rule, and material conflicts of interest.

- **CC-13 — Profile Relativity.** Does not present a profile-relative Support Assessment as profile-independent, universal, or equivalent to an assessment under another Profile without an explicit governed comparison or translation rule.

- **CC-14 — Assessment–Decision Separation.** Keeps evidentiary support distinct from the Relying Party’s action, risk tolerance, precautionary policy, legal obligation, or other decision basis.

- **CC-15 — Terminal Premises.** Identifies terminal premises, their stable references, types, sources or authorities, scopes, grounds for terminal treatment, contestability, temporal applicability, and consequences of rejection or failure.

- **CC-16 — Normative Support.** Represents every normative premise and normative warrant required for a normative conclusion and distinguishes factual support from adoption, authority, applicability, interpretation, moral justification, or universal validity.

- **CC-17 — Non-Occurrence Discipline.** Attributes categorical non-occurrence only where sufficiently complete and functioning observation is supported; probabilistic non-occurrence requires a calibrated detection and sampling model, uncertainty, false-negative characteristics, and material base-rate or prior assumptions.

- **CC-18 — Independence Discipline.** Does not treat multiple artifacts, signatures, witnesses, or organizations as independent support without analysis of shared observations, collectors, operators, control planes, keys, time sources, infrastructures, incentives, and terminal dependencies.
