# Unresolved Limitations — Witnessability Conceptual Core 1.0 RC2

These limitations do not reopen the frozen Core text unless they reveal a contradiction, counterexample, or implementation-blocking defect. They qualify the release package and direct subsequent work.

1. The first Release Evaluation Profile is authored or controlled by the evaluated project and is not independent external validation.
2. The first self-application depends on the named bootstrap terminal premise `TP-BOOTSTRAP-001` because no prior ratified Witnessability release-governance regime exists.
3. The Abstract Formal Core is an abstract signature and safety-constraint set, not a complete proof theory, denotational semantics, probabilistic semantics, or machine-checked foundation.
4. Logical independence of W-I1 through W-I8 has not been demonstrated; separating-model construction remains in Formal Foundations backlog item `FF-INV-IND`.
5. Full semantics of warrant soundness, defeater acceptance, composition, uncertainty aggregation, and profile translation remain for the Evaluation Specification and Formal Foundations.
6. Named prior-art mapping remains companion academic work and is not a normative dependency of the Core.
7. Corpus reconciliation of L0–L5 and WL1–WL5 is expressed in the Corpus Compatibility Note and must be implemented by explicit, gate-respecting, monotone projection rules in the relevant profiles.
8. External adversarial review and domain-profile test vectors remain future validation activities.

9. The review-session hash verification establishes identity only for artifacts observed in that session; binding to other local custody copies requires separate verification.

10. The review-session statements were produced by an AI system engaged by the evaluated party; reviewer organizational independence and independent human peer review are not established or claimed.
11. RS-02 attests the source package revision identified in its statement, not the later package revision incorporating RS-02 and the reviewer-attribution records.
12. Terminal binding of the final manifest and canonical ZIP remains pending until an external attributed ratification attestation is completed.
