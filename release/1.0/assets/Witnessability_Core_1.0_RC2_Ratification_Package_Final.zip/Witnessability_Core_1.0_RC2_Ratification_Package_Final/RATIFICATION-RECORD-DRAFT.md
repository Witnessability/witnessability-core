# Ratification Record — Witnessability Conceptual Core 1.0

**Status:** Draft; no ratification decision has been made.

## Proposed bounded decision

Approve the exact frozen RC2 source, the declared status-block-only Transformation Transition, and the exact Stable candidate for issuance under the publication filename `WITNESSABILITY-CORE-1.0.md`, but only after every blocking gate in the bound Release Evaluation Profile is satisfied.

This is a governance and release decision. It is not a claim that the Core is complete, infallible, empirically proven, formally exhaustive, immune to future counterexamples, or independently validated merely because the release process was completed.

## Artifacts proposed for ratification

| Role | File | SHA-256 |
|---|---|---|
| Frozen verified source | `WITNESSABILITY-CORE-1.0-RC2-FROZEN.md` | `3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04` |
| Declared transformation | `STATUS-TRANSFORMATION-SPEC.yaml` | `942aa01053e80c5146e54d5f26fe712650fd2130bc2aab59ef1bfc4944f0b66d` |
| Stable output candidate | `WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md` | `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034` |
| Release Evaluation Profile | `RELEASE-EVALUATION-PROFILE-RC2.yaml` | `e2d5b27e0b107a1d1f800e9b66a17057075cafa5146347502a65d4b48f100958` |
| Release Witness Case | `RELEASE-WITNESS-CASE-RC2.yaml` | `cdf6574dbeb576309b5473839d47912c4e151e6be5bc40bc33b3a764cb184332` |

## Profile amendment condition

The selected Release Evaluation Profile was amended after inspection by the selecting party under amendment `PA-STATUS-HASH-BINDING-001`. The amendment is disclosed in `PROFILE-AMENDMENT-RECORD.md`, did not select an alternative Profile, and requires full re-evaluation under the amended Profile before ratification.

## Transformation and issuance condition

The Stable candidate differs from the frozen RC2 source only by the two substitutions declared in `STATUS-TRANSFORMATION-SPEC.yaml` and verified in `STATUS-TRANSFORMATION-VERIFICATION-REPORT.md`.

After ratification, the candidate bytes may be issued as `WITNESSABILITY-CORE-1.0.md`. The issued file must retain SHA-256 `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`. Any byte change places the artifact outside this ratification and requires new evaluation and ratification.

## Required self-application disclosures

- Terminal premise: `TP-BOOTSTRAP-001`.
- Conflict of interest: `COI-PROFILE-AUTHORSHIP-001`.
- Session-local custody/binding qualification: `BINDING-SESSION-LOCAL-001`.
- Post-inspection profile amendment: `PROFILE-AMENDMENT-AFTER-INSPECTION-001`.
- Reviewer attribution and independence qualification: `REVIEWER-NATURE-001`.

These qualifications remain attached to any final Support Assessment and ratification decision.


## RS-02 integration materials

The following materials supplement, but do not silently replace, the pinned Release Witness Case:

| Role | File | SHA-256 |
|---|---|---|
| Reviewer-provided statement 02 | `REVIEW-SESSION-VERIFICATION-STATEMENT-02.md` | `a552c87423c61e80896af6738fba2abda588b9ad9f61e4042fd1a01f6be03301` |
| Reviewer attribution and qualifications | `REVIEWER-ATTRIBUTION-AND-QUALIFICATIONS.md` | `baefb875f0c6f86873a2f15826ac60767d2b71ab7b59e2b415365cde253d2848` |
| Release Witness Case integration supplement | `RELEASE-WITNESS-CASE-RC2-RS02-SUPPLEMENT.yaml` | `ab46cb8339a47f03a67326fcbc053068525bc00da8542a01c3701fc26a508625` |
| Incorporation delta | `INCORPORATION-DELTA-SPEC.yaml` | `26db4bb86712edc44efe341e3a006a63e10778724644fa72a30fe82929b23238` |
| Reproducible verification procedure | `verify-release.sh` | `622b691b4eb37faa29f6533e550dee56c47f506e511f476937c02a0bf804341f` |

The base `RELEASE-WITNESS-CASE-RC2.yaml` remains byte-identical at SHA-256 `cdf6574dbeb576309b5473839d47912c4e151e6be5bc40bc33b3a764cb184332`. The final decision must consider the base Case and its RS-02 integration supplement jointly.

RS-02 attests only the source package revision identified by ZIP SHA-256 `72c66132fa086d6e2fd22fd3820ac91b314d60282d5bcee05e7e1d145ec9bdc7` and source sums SHA-256 `64a2d57ba4b47e5fa0a8b1562bfb984a4577046dbabdde4ea2825dd74385ef0e`. It must not be represented as attesting the resulting package revision.

## External terminal binding condition

The final `SHA256SUMS-RC2-RATIFICATION.txt` hash and canonical ZIP hash must be stated in an attributed `RATIFICATION-ATTESTATION.md` outside the ZIP whose hash it certifies. The attestation must also reference `INCORPORATION-DELTA-SPEC.yaml`, `REVIEWER-NATURE-001`, and the existing required self-application disclosures.

No terminal signature or ratification decision is created by this draft.

## Decision state

`PENDING`

The state must not be changed to `RATIFIED` until the exact artifacts and hashes above, the full release package, and all blocking gates have been reviewed and approved by the identified release authority.
