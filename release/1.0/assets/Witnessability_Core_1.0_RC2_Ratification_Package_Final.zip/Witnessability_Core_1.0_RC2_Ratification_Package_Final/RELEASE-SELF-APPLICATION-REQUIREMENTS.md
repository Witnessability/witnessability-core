# Release Self-Application Requirements

## Purpose

The release package applies the Witnessability conceptual discipline to the status claim made about the Core itself.

`Stable` is a bounded governance and release status. It is not a claim that every proposition in the document is true, that the model is complete, or that no future revision will be required.

## Required release artifacts

- `WITNESSABILITY-CORE-1.0.md`
- a human-readable rendered edition
- `CHANGELOG.md`
- `REVIEW-DISPOSITION.md`
- `CONCEPTUAL-CONSISTENCY-MAPPING.md`
- `RELEASE-EVALUATION-PROFILE.yaml`
- `RELEASE-WITNESS-CASE.yaml`
- `RATIFICATION-RECORD.md`
- cryptographic hashes
- attribution/signature or other declared issuance mechanism
- unresolved limitations and future-work register

## Required Target Proposition

A release case should evaluate a proposition such as:

> Under the identified Release Evaluation Profile and review process, the identified document version has completed the specified conceptual hardening, disposition, consistency-mapping, and ratification steps required for the governance status `Stable`.

This proposition is about process completion and governance status, not universal correctness or completeness.

## TP-BOOTSTRAP-001 — First self-application bootstrap condition

The first Release Witness Case uses a Release Evaluation Profile whose governance expectations are derived from the document being released.

This is an unavoidable bootstrap condition of first self-application and must be represented as a named terminal premise, not hidden as an ordinary limitation.

Required fields:

- stable identifier: `TP-BOOTSTRAP-001`;
- type: institutional/definitional bootstrap terminal premise;
- scope: first release self-application only;
- basis for terminal treatment: no earlier ratified Witnessability release governance exists;
- contestability: open to external challenge and replacement by later independently governed profiles;
- consequence of rejection: release status cannot be represented as independently ratified under a prior Witnessability regime.

## COI-PROFILE-AUTHORSHIP-001 — Disclosed profile authorship conflict

The evaluated party authors or controls the first Release Evaluation Profile.

This must be disclosed as:

- a material dependency;
- a potential conflict of interest;
- a limitation on claims of independence;
- a reason to distinguish self-consistency review from independent external review.

It does not automatically invalidate the release profile or the governance decision.

## Profile pre-commitment

The Release Evaluation Profile and its selection rule should be frozen before final evaluation by the selecting party. Any later change is versioned, attributable, justified, and triggers re-evaluation or an explicit exception record.

## Status lifecycle

- The internal draft labelled `Stable` was not published.
- The premature label is preserved in the changelog as an error.
- RC2 supersedes that pre-release status.
- `Stable` may be assigned only through the ratification record after all blocking disposition items are verified.

## Ratification language

The ratification record states that release is a governance act based on the identified evidence, profile, assumptions, terminal premises, qualifications, and unresolved limitations.

It must not state or imply that the release proves:

- completeness of the ontology;
- empirical truth of every proposition;
- formal independence of the eight invariants;
- absence of future counterexamples;
- independence of self-authored review materials.

## Two-stage status transformation

The frozen RC2 artifact remains immutable and retains SHA-256 `3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04`. A distinct prospective Stable artifact must be derived only through the declared `status-block-only substitution` in `STATUS-TRANSFORMATION-SPEC.yaml`.

The Release Witness Case and Ratification Record must bind:

- the frozen source hash;
- the transformation specification and verification report;
- the Stable-candidate hash;
- the requirement that the issued publication artifact is byte-identical to the candidate.

Changing the embedded status text without recording a Transformation Transition is a prohibited silent mutation.

## Post-inspection Profile amendment

If the selected Release Evaluation Profile is amended after inspection by the selecting party, the release package must disclose the amendment, preserve the superseded Profile identifier and hash, state whether any alternative Profile was considered or selected, freeze the amended Profile before evaluation, and perform complete re-evaluation under the amended Profile.

## Reviewer attribution and terminal package binding

Review-session materials must identify whether a reviewer is human, AI, institutional, accredited, or otherwise situated. Where an AI reviewer is engaged by the evaluated party and material selection is controlled by that party, the relationship, limits of cross-session identity, custody limitations, and absence of claimed organizational independence must be disclosed.

A review-session statement may support only the exact source revision it identifies. Incorporation of the statement into a later package revision requires a declared delta and fresh package verification.

The final `SHA256SUMS` and canonical ZIP hashes must be bound by an attributed terminal ratification act outside the ZIP whose hash is certified. The terminal act must not be inserted into the certified ZIP after its hash is computed.
