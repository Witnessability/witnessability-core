# Corpus Compatibility Note — RC2 Companion

## Purpose

This companion note reconciles the RC2/future Stable Conceptual Core with earlier corpus constructions without reintroducing a universal scalar notion of Witnessability.

## 1. L0–L5 and WL1–WL5

The L and WL scales are to be defined as:

> **profile-specific ordinal projections of multidimensional Support Envelopes**

They are not natural scalar values of Witnessability and are not universal trust scores.

### Projection acceptance criteria

Let a profile-relative ordinal projection be:

\[
\pi_P:\mathcal E_P/{\sim_P}\rightarrow\mathcal O_P
\]

where \(\mathcal O_P\) is an ordered set of profile-specific levels.

A justified projection must satisfy at least:

1. **Gate-respecting condition.** An envelope with an unknown or unsatisfied mandatory gate is not mapped to a level whose semantics imply that the gate is satisfied.

2. **Profile-relative monotonicity.** If:

\[
[e_1]_P\preceq_P[e_2]_P
\]

then:

\[
\pi_P([e_1]_P)\leq\pi_P([e_2]_P)
\]

3. **Explicit information loss.** The Profile states which dimensions, distinctions, and incomparable envelopes are collapsed by the projection.

4. **Non-compensation disclosure.** Mandatory gates and non-compensatory dimensions are explicitly identified.

5. **Scope limitation.** The projection identifies the Target Proposition classes and domains for which it is defined.

6. **Forbidden interpretation.** The level is not presented independently of the defining Profile or as a universal measure of truth, trust, integrity, or independence.

## 2. Boundary Ceiling Rule

### Derived-rule statement

Where support for a proposition depends on crossing an evidentially material boundary, interface, transition, or Binding Relation, no downstream Support Envelope may attribute preservation of a material property beyond what is established across that construct, unless an explicit preservation warrant or an independent additional basis licenses the stronger attribution.

### Derivation sketch

1. W-I7 prohibits increasing a Support Envelope without an explicit warrant and every required additional premise or basis.
2. The Boundary Architecture requires material-property preservation across a boundary construct to be separately established rather than assumed.
3. A downstream claim that a property survived a crossing is therefore an amplification unless the preservation relation is supported.
4. W-I7 blocks that amplification in the absence of a preservation warrant or independent additional basis.
5. The Boundary Ceiling Rule is the specialization of these two constraints to property preservation across boundary constructs.

The rule is derived in this limited conceptual sense; a formal theorem requires a completed semantics of envelopes, warrants, and boundary-preservation relations.

## 3. Conditional independence corollary for WL5-type claims

Where every materially relevant witness, collector, trust anchor, control plane, and terminal dependency is controlled by the evaluated operator, the resulting support must not be represented as independent of that operator unless an additional independent basis establishes the claimed independence.

This is a profile-dependent conditional corollary, not yet a formally proved theorem.

The same rule applies to hyperscalers, WitSeal, or any other provider without exception.
