# RS-02 Integration Disposition

## Identified instruction conflict

The integration order required both:

1. modification and version-bump of `RELEASE-WITNESS-CASE-RC2.yaml`; and
2. preservation of the pinned hash of that same Witness Case, with any change treated as a stop condition.

Both requirements cannot be satisfied by mutating the same file.

## Resolution

The pinned base Witness Case is preserved byte-for-byte:

- file: `RELEASE-WITNESS-CASE-RC2.yaml`
- SHA-256: `cdf6574dbeb576309b5473839d47912c4e151e6be5bc40bc33b3a764cb184332`

RS-02 integration is represented by a separate, versioned supplement:

- `RELEASE-WITNESS-CASE-RC2-RS02-SUPPLEMENT.yaml`

The supplement explicitly references and composes with the pinned base Case. It adds `REVIEWER-NATURE-001`, RS-02, the reviewer-attribution record, the verification procedure, and the incorporation-delta record without silently rewriting the historical Case.

## Rationale

This resolution:

- preserves the pinned ratification baseline;
- keeps `verify-release.sh` unchanged;
- avoids silent mutation of a historical Witness Case;
- makes the integration transition explicit and reviewable;
- permits terminal ratification to bind both the base Case and its integration supplement.

This is a controlled modification of the requested integration method, not a rejection of N-1 or N-2.
