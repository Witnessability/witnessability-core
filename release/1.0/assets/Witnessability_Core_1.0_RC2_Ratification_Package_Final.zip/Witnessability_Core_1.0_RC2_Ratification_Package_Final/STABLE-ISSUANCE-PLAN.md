# Stable Issuance Plan

## Two-stage release scheme

1. Ratify the immutable frozen source artifact: `WITNESSABILITY-CORE-1.0-RC2-FROZEN.md` (`3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04`).
2. Ratify the declared status-only transformation in `STATUS-TRANSFORMATION-SPEC.yaml`.
3. Ratify the exact output candidate: `WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md` (`382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`).
4. After ratification, issue the candidate bytes under the publication filename `WITNESSABILITY-CORE-1.0.md` without any content change.
5. Verify the issued file has SHA-256 `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`.

The frozen RC2 source remains preserved permanently as the input to the Transformation Transition. The Stable artifact is a distinct artifact with distinct provenance and hash.

## Prohibited shortcut

Editing the frozen artifact in place and continuing to cite the frozen SHA-256 is prohibited. Any published artifact whose SHA-256 differs from `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034` is outside the current Release Witness Case.
