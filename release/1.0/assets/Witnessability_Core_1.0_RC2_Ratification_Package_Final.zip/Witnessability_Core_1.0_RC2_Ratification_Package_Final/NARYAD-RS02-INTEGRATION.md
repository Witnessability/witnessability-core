# Наряд: интеграция RS-02 и финализация ратификационного пакета

**Исполнитель:** локальный агент (Claude Code / Codex CLI)
**Основание:** решение release authority о принятии N-1/N-2 (сессия 2026-07-24)
**Входные артефакты из сессии (проверить хэши при приёмке):**

| Файл | SHA-256 (как записан в сессии) |
|---|---|
| `REVIEW-SESSION-VERIFICATION-STATEMENT-02.md` | `a552c87423c61e80896af6738fba2abda588b9ad9f61e4042fd1a01f6be03301` |
| `verify-release.sh` | `622b691b4eb37faa29f6533e550dee56c47f506e511f476937c02a0bf804341f` |

При несовпадении хэша на приёмке (например, из-за конверсии line endings) — считать передачу неуспешной и запросить повтор; **не** перехэшировать молча.

## Шаги

1. **Приёмка RS-02.** Сверить хэш. Зафиксировать intake-хэш в Witness Case как хэш материала RS-02. URN уже проставлен в шапке: `urn:witnessability:review-statement:RS-02`.

2. **REVIEWER-NATURE-001** — добавить в `material_dependencies` Release Witness Case (блок готов к вставке):

```yaml
- id: REVIEWER-NATURE-001
  type: reviewer_attribution_and_independence_qualification
  text: Review-session statements RS-01 and RS-02 were produced by an AI system (Claude, provided by Anthropic) engaged by the evaluated party within individual user sessions; cross-session reviewer identity is hash-mediated, not cryptographically continuous.
  independence_status: not_established
  organizational_independence: not_claimed
  material_selection_control: evaluated_party
  observation_locus: files_provided_in_the_respective_review_session
  statements:
  - id: urn:witnessability:review-statement:RS-01
    path: REVIEW-SESSION-HASH-VERIFICATION-STATEMENT.md
    sha256: f90bbadd3b24b30b6108948c034d69021b688125be730fc7055a458110fe40c4
  - id: urn:witnessability:review-statement:RS-02
    path: REVIEW-SESSION-VERIFICATION-STATEMENT-02.md
    sha256: <intake-хэш из шага 1>
  effects:
  - limits_weight_as_independent_validation
  - requires_disclosure_before_external_presentation
  - motivates_independent_external_review
```

3. **REVIEWER-ATTRIBUTION-AND-QUALIFICATIONS.md** — создать; содержание: оба statement (RS-01 с ретроактивным URN `urn:witnessability:review-statement:RS-01`, RS-02), общие ограничения AI-рецензирования (секции 1 и 5 RS-02 как основа), ссылка на REVIEWER-NATURE-001.

4. **INCORPORATION-DELTA-SPEC** — создать объявленную дельту инкорпорации (зеркало status-transformation): источник = пакет-ревизия `zip 72c66132…9bdc7` / `sums 64a2d57b…85ef0e`; операции = добавление RS-02, verify-release.sh, REVIEWER-ATTRIBUTION-AND-QUALIFICATIONS.md, INCORPORATION-DELTA-SPEC; правка RELEASE-WITNESS-CASE (REVIEWER-NATURE-001 + новые witness_materials + version bump); пересчёт MANIFEST и SHA256SUMS. Критично: RS-02 аттестует **источник** дельты, не результат (см. §5 RS-02).

5. **Обновить** `RELEASE-WITNESS-CASE-RC2.yaml` (version bump, новые материалы), `MANIFEST.json`, пересчитать `SHA256SUMS` (44 → N записей).

6. **Прогнать** `bash verify-release.sh` из корня пакета — ожидаемо: V-G1 отразит новое N/N, остальные гейты PASS. При изменении состава pinned-гейтов скрипт не трогать: pinned-хэши пяти ратификационных артефактов и двух базовых текстов измениться не должны; изменение любого из них = стоп и эскалация.

7. **Собрать canonical ZIP** финальной ревизии. Вычислить: хэш нового SHA256SUMS, хэш ZIP.

8. **RATIFICATION-ATTESTATION.md — строго вне ZIP.** Содержит: пять хэшей ратификационной таблицы, intake-хэш RS-02, хэш финального SHA256SUMS, хэш финального ZIP, ссылку на INCORPORATION-DELTA-SPEC, четыре обязательные квалификации (TP-BOOTSTRAP-001, COI-PROFILE-AUTHORSHIP-001, BINDING-SESSION-LOCAL-001, PROFILE-AMENDMENT-AFTER-INSPECTION-001) + REVIEWER-NATURE-001. Detached-подпись: `RATIFICATION-ATTESTATION.md.sig` (или подпись поверх ZIP).

9. **Governance-решение** о ратификации — вне компетенции агента; подготовить всё к подписи и остановиться.

10. **После ратификации:** выпустить `WITNESSABILITY-CORE-1.0.md` из байтов STABLE-CANDIDATE; проверить, что выпущенный файл несёт SHA-256 `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`; любое расхождение = вне ратификации.

## Инварианты наряда

- Замороженный текст Core (`3120657d…fbbd04`) не редактируется ни на байт.
- Ни один существующий файл пакета не удаляется; supersession — только через `_archive/` с сохранением хэшей.
- Терминальный акт (attestation + подпись) никогда не попадает внутрь ZIP, чей хэш удостоверяет.
