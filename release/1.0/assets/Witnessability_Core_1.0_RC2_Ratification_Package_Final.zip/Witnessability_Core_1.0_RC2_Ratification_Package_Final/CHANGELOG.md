# Changelog

## 1.0 RC2 — Pre-publication hardening

- Corrected the pre-release lifecycle status: an internal draft was erroneously labelled `Stable` before completion of the release process.
- The erroneous label was withdrawn before publication and is preserved in this changelog rather than silently overwritten.
- RC2 supersedes that internal status pending incorporation and verification of the controlled hardening findings.
- Established a finding → decision → text-anchor → verification change-control process to prevent `accepted-but-dropped` review losses.
- Reserved final `Stable` status for a ratified release under an identified Release Evaluation Profile and Release Witness Case.
- Applied and anchor-verified RC2 patches P-001 through P-012 to the controlled working copy.
- Added Profile Governance, Terminal Premises, normative-support clarification, Boundary Ceiling Rule, empty-frontier semantics, and warrant-bound composition with qualification inheritance.
- Appended Conceptual Consistency Checklist CC-1 through CC-18 and generated an RC2 Conceptual Consistency Mapping.
- Created draft Release Evaluation Profile, Release Witness Case, and Ratification Record; no Stable status has been assigned.
- Recorded insertion of the Boundary Ceiling Rule as §6.5 and consequent renumbering of Non-Equivocation and Long-Term Verifiability to §§6.6–6.7.
- Frozen RC2 was created as a governance act over byte-identical controlled text; both artifacts share SHA-256 `3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04`.
- Defined a two-stage RC2→Stable release transition: the immutable frozen RC2 source is ratified together with a mechanically verified status-block-only substitution and a distinct Stable candidate hash.
- Disclosed and versioned a post-inspection amendment of the selected Release Evaluation Profile after review identified the embedded-status/hash binding defect; no alternative Profile was selected, and full re-evaluation is required.

## 1.0 pre-RC2 internal draft

- Consolidated the Conceptual Core, eight invariants, Boundary Architecture, and Abstract Formal Core.
- Internal status label `Stable` was premature and had no completed Release Witness Case or ratification record.

### RS-02 integration hardening

- Accepted `REVIEW-SESSION-VERIFICATION-STATEMENT-02.md` verbatim at SHA-256 `a552c87423c61e80896af6738fba2abda588b9ad9f61e4042fd1a01f6be03301`.
- Added explicit AI-reviewer attribution and independence qualifications under `REVIEWER-NATURE-001`.
- Preserved the pinned base Release Witness Case at SHA-256 `cdf6574dbeb576309b5473839d47912c4e151e6be5bc40bc33b3a764cb184332` and represented new material in a versioned integration supplement rather than silently mutating the historical Case.
- Added a declared incorporation delta, reproducible verification script, integration disposition, and integration verification report.
- Required the final manifest and canonical ZIP to be bound by an external terminal ratification attestation outside the ZIP.
- No Stable status was assigned and the ratification gate remains unsatisfied.
