#!/usr/bin/env bash
# verify-release.sh — Witnessability Conceptual Core 1.0 RC2 Ratification Package
# Reproducible verification of the release package. Run from the package root.
#
# Exit code: 0 = all gates PASS, 1 = any gate FAIL.
# Dependencies: bash, sha256sum, patch, diff, cmp, wc, mktemp (POSIX + GNU coreutils).
#
# This script is a verification PROCEDURE, not a witness. Per the Core's own
# discipline, a mechanism strengthens only the propositions it is capable of
# supporting: this script verifies internal consistency and reproducibility of
# the package bytes it is pointed at. It does not establish custody, authorship,
# ratification, or the truth of the Conceptual Core.
#
# The script's own integrity is covered by the package manifest and, terminally,
# by the external ratification attestation. It cannot verify itself from inside.

set -u

# --- Pinned ratification baseline (must match RATIFICATION-RECORD) -----------
FROZEN_SHA="3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04"
STABLE_SHA="382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034"
TRANSFORM_SHA="942aa01053e80c5146e54d5f26fe712650fd2130bc2aab59ef1bfc4944f0b66d"
PROFILE_SHA="e2d5b27e0b107a1d1f800e9b66a17057075cafa5146347502a65d4b48f100958"
WCASE_SHA="cdf6574dbeb576309b5473839d47912c4e151e6be5bc40bc33b3a764cb184332"
AMEND_SHA="1b5504212034f15ae28ffa94df2ccc7a276b5fabbe7f9eea9459070c3a3fb37a"
SUPERSEDED_PROFILE_SHA="dfed32863eed62d50d414e6770f903cb49e72d085d3a5827b98806bbc5153afd"
EXPECTED_LINES="2211"

FROZEN="WITNESSABILITY-CORE-1.0-RC2-FROZEN.md"
STABLE="WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md"
SUMS="SHA256SUMS-RC2-RATIFICATION.txt"
STATUS_PATCH="RC2-TO-STABLE-STATUS-DIFF.patch"
CHAIN_PATCH="RC2-PATCH-DIFF.patch"
PREPATCH="_archive/pre-freeze/WITNESSABILITY-CORE-1.0-RC2-WORKING.prepatch.md"
ARCH_CONTROLLED="_archive/pre-freeze/WITNESSABILITY-CORE-1.0-RC2-CONTROLLED.md"
SUPERSEDED_PROFILE="_archive/pre-ratification/RELEASE-EVALUATION-PROFILE-RC2.pre-status-transition.yaml"

PASS=0; FAIL=0; RESULTS=""

sha() { sha256sum "$1" 2>/dev/null | awk '{print $1}'; }

gate() { # gate <ID> <description> <0|1 pass>
  local id="$1" desc="$2" ok="$3" state
  if [ "$ok" -eq 0 ]; then state="PASS"; PASS=$((PASS+1)); else state="FAIL"; FAIL=$((FAIL+1)); fi
  RESULTS="${RESULTS}$(printf '%-24s %-4s %s' "$id" "$state" "$desc")\n"
}

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT

# V-G1: full manifest check
if [ -f "$SUMS" ]; then
  total=$(wc -l < "$SUMS" | tr -d ' ')
  okcnt=$(sha256sum -c "$SUMS" 2>/dev/null | grep -c ": OK$")
  [ "$okcnt" = "$total" ] && [ "$total" -gt 0 ]; gate "V-G1-MANIFEST" "sha256sum -c: ${okcnt}/${total} OK" $?
else
  gate "V-G1-MANIFEST" "manifest file missing" 1
fi

# V-G2: frozen source hash
[ "$(sha "$FROZEN")" = "$FROZEN_SHA" ]; gate "V-G2-FROZEN" "frozen source SHA-256 matches pinned baseline" $?

# V-G3: stable candidate hash
[ "$(sha "$STABLE")" = "$STABLE_SHA" ]; gate "V-G3-STABLE" "stable candidate SHA-256 matches pinned baseline" $?

# V-G4: status transformation reproduces stable candidate
cp "$FROZEN" "$TMP/repro.md" 2>/dev/null && patch -s "$TMP/repro.md" < "$STATUS_PATCH" 2>/dev/null
[ "$(sha "$TMP/repro.md")" = "$STABLE_SHA" ] && cmp -s "$TMP/repro.md" "$STABLE"
gate "V-G4-TRANSFORM" "frozen + status patch reproduces stable candidate byte-exactly" $?

# V-G5: status diff is exactly two substitutions (2 removed + 2 added content lines)
if [ -f "$STATUS_PATCH" ]; then
  ch=$(grep -Ec '^[+-][^+-]' "$STATUS_PATCH")
  [ "$ch" -eq 4 ]; gate "V-G5-DIFF-SCOPE" "status diff contains exactly 2 substitutions (${ch}/4 changed lines)" $?
else
  gate "V-G5-DIFF-SCOPE" "status patch missing" 1
fi

# V-G6: patch chain reproduces controlled/frozen
cp "$PREPATCH" "$TMP/chain.md" 2>/dev/null && patch -s "$TMP/chain.md" < "$CHAIN_PATCH" 2>/dev/null
[ "$(sha "$TMP/chain.md")" = "$FROZEN_SHA" ] && [ "$(sha "$ARCH_CONTROLLED")" = "$FROZEN_SHA" ]
gate "V-G6-LINEAGE" "prepatch + patch chain = CONTROLLED = FROZEN (single hash)" $?

# V-G7: ratification-table cross-hashes
okx=0
[ "$(sha STATUS-TRANSFORMATION-SPEC.yaml)" = "$TRANSFORM_SHA" ] || okx=1
[ "$(sha RELEASE-EVALUATION-PROFILE-RC2.yaml)" = "$PROFILE_SHA" ] || okx=1
[ "$(sha RELEASE-WITNESS-CASE-RC2.yaml)" = "$WCASE_SHA" ] || okx=1
[ "$(sha PROFILE-AMENDMENT-RECORD.md)" = "$AMEND_SHA" ] || okx=1
gate "V-G7-CROSSHASH" "transformation spec, profile, witness case, amendment record match pinned hashes" $okx

# V-G8: superseded profile preserved with matching hash
[ "$(sha "$SUPERSEDED_PROFILE")" = "$SUPERSEDED_PROFILE_SHA" ]
gate "V-G8-SUPERSEDED" "superseded pre-amendment profile preserved, hash matches" $?

# V-G9: line counts preserved across status transformation
fl=$(wc -l < "$FROZEN" 2>/dev/null | tr -d ' '); sl=$(wc -l < "$STABLE" 2>/dev/null | tr -d ' ')
[ "$fl" = "$EXPECTED_LINES" ] && [ "$sl" = "$EXPECTED_LINES" ]
gate "V-G9-LINECOUNT" "frozen and stable candidate both ${EXPECTED_LINES} lines (got ${fl}/${sl})" $?

# V-G10: no premature Stable status in frozen source; candidate carries Stable
grep -q '^\*\*Status: Release Candidate 2' "$FROZEN" && grep -q '^\*\*Status: Stable\*\*$' "$STABLE"
gate "V-G10-STATUSLINES" "frozen carries RC2 status; candidate carries Stable status" $?

# --- Report ------------------------------------------------------------------
echo "=============================================================================="
echo " Witnessability Core 1.0 RC2 Ratification Package — mechanical verification"
echo "=============================================================================="
printf "%b" "$RESULTS"
echo "------------------------------------------------------------------------------"
echo " Gates passed: ${PASS}  failed: ${FAIL}"
if [ "$FAIL" -eq 0 ]; then
  echo " RESULT: PASS — package is internally consistent and reproducible."
  echo " NOTE: This result is not a ratification and does not satisfy G-RATIFICATION."
  exit 0
else
  echo " RESULT: FAIL — do not ratify until every failed gate is explained or fixed."
  exit 1
fi
