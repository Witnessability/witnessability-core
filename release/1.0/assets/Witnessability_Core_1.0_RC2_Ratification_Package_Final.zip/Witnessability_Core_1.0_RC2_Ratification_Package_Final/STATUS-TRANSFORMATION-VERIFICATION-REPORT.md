# Status Transformation Verification Report

## Result

**Verified.** The prospective Stable artifact is derived from the frozen RC2 artifact solely by the declared status-block substitution.

| Property | Result |
|---|---|
| Source SHA-256 | `3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04` |
| Stable-candidate SHA-256 | `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034` |
| Source line count | 2211 |
| Output line count | 2211 |
| Removed lines | 2 |
| Added lines | 2 |
| Changed source lines | 5 and 11 |
| Other content changes | None |

## Declared substitutions

1. `**Status: Release Candidate 2 (pre-publication hardening)**` → `**Status: Stable**`
2. `This document defines the release-candidate conceptual core of Witnessability pending completion of the RC2 hardening pass and release ratification.` → `This document defines the stable conceptual core of Witnessability.`

The complete mechanically reproducible diff is stored in `RC2-TO-STABLE-STATUS-DIFF.patch`.

## Release constraint

Upon ratification, the published `WITNESSABILITY-CORE-1.0.md` must be byte-identical to `WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md` and must therefore have SHA-256 `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`. Any byte change requires a new transformation record, re-evaluation, and a new ratification binding.
