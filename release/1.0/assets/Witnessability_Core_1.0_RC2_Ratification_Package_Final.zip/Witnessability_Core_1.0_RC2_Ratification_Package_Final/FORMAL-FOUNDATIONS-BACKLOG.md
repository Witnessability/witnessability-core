# Formal Foundations and Companion Work Backlog

This file preserves accepted obligations intentionally deferred beyond the Conceptual Core 1.0 freeze.

| ID | Work item | Reason deferred | Completion evidence |
|---|---|---|---|
| FF-INV-IND | Construct an independence/separation model for each W-I1…W-I8: a model satisfying the other seven while violating the selected invariant, or revise the claim that independence is a demonstrated property. | Requires formal model classes and semantics not defined in the Core. | Eight separating models or a published dependency analysis showing which invariants are not independent. |
| FF-WARRANT | Define warrant syntax and validity/soundness conditions. | Domain- and logic-sensitive. | Formal semantics plus adversarial examples. |
| FF-DEFEATER | Define rebutting, undercutting, premise, authority, and binding defeaters. | Better located in Information Model/Formal Foundations. | Machine-readable types and evaluation rules. |
| FF-FRONTIER | Study conditions ensuring nonempty maximal frontiers, closure/limit representations, and computable approximations. | Requires topological/order-theoretic assumptions. | Theorems and counterexamples. |
| FF-COMP | Define conservative composition semantics, qualification inheritance, contradiction handling, and shared-dependency collapse. | Core only states safety constraints. | Formal operator semantics and test vectors. |
| FF-PROFILE | Define profile soundness review, translation relations, profile-shopping detection, and governance conformance. | Requires governance and evaluation specification. | Profile conformance clauses and adversarial profiles. |
| FF-PROB | Define probabilistic support and negative-claim semantics including priors/base rates. | Avoid premature universal Bayesian commitment in Core. | Profile-specific probabilistic semantics. |
| FF-PROJECTION | Formalize justified ordinal projections for L/WL levels. | Corpus compatibility work. | Gate-respecting and monotone projection definitions and tests. |
| IM-GRAPH | Produce machine-readable Witness Case Information Model. | Next specification layer. | Schema/ontology plus positive and negative examples. |
| AC-PRIOR | Named prior-art mapping: Toulmin, Wigmore, Dung, Pollock, GSN/SACM, W3C PROV, RATS, SCITT, digital forensics. | Academic positioning, not Core ontology. | Comparative matrix and citations. |
| AC-TEST | Create adversarial test vectors, including accepted-but-dropped review transmission. | Requires concrete profiles and information model. | Executable or reviewable test corpus. |
