# Release Binding Record — Witnessability Conceptual Core 1.0 RC2

| Role | Artifact | SHA-256 |
|---|---|---|
| Frozen verified source | `WITNESSABILITY-CORE-1.0-RC2-FROZEN.md` | `3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04` |
| Stable output candidate | `WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md` | `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034` |
| Transformation specification | `STATUS-TRANSFORMATION-SPEC.yaml` | `942aa01053e80c5146e54d5f26fe712650fd2130bc2aab59ef1bfc4944f0b66d` |
| Release Evaluation Profile | `RELEASE-EVALUATION-PROFILE-RC2.yaml` | `e2d5b27e0b107a1d1f800e9b66a17057075cafa5146347502a65d4b48f100958` |
| Release Witness Case | `RELEASE-WITNESS-CASE-RC2.yaml` | `cdf6574dbeb576309b5473839d47912c4e151e6be5bc40bc33b3a764cb184332` |
| Profile Amendment Record | `PROFILE-AMENDMENT-RECORD.md` | `1b5504212034f15ae28ffa94df2ccc7a276b5fabbe7f9eea9459070c3a3fb37a` |
| RS-02 review statement | `REVIEW-SESSION-VERIFICATION-STATEMENT-02.md` | `a552c87423c61e80896af6738fba2abda588b9ad9f61e4042fd1a01f6be03301` |
| Reviewer attribution record | `REVIEWER-ATTRIBUTION-AND-QUALIFICATIONS.md` | `baefb875f0c6f86873a2f15826ac60767d2b71ab7b59e2b415365cde253d2848` |
| RS-02 integration supplement | `RELEASE-WITNESS-CASE-RC2-RS02-SUPPLEMENT.yaml` | `ab46cb8339a47f03a67326fcbc053068525bc00da8542a01c3701fc26a508625` |
| Incorporation delta | `INCORPORATION-DELTA-SPEC.yaml` | `26db4bb86712edc44efe341e3a006a63e10778724644fa72a30fe82929b23238` |
| Verification procedure | `verify-release.sh` | `622b691b4eb37faa29f6533e550dee56c47f506e511f476937c02a0bf804341f` |
| Ratification Record | `RATIFICATION-RECORD-DRAFT.md` | Pending final decision |

The frozen source and Stable candidate are distinct artifacts connected by the verified Transformation Transition. This record does not assign `Stable` status before ratification.

The base Release Witness Case remains the pinned historical case. The RS-02 integration supplement is jointly material to the final ratification decision and does not silently replace the base Case.
