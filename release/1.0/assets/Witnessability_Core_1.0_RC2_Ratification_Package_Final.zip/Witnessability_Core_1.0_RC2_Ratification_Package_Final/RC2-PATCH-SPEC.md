# RC2 Atomic Patch Specification

## Patch discipline

Each patch is applied independently. After application, the final unique text anchor is copied into `REVIEW-DISPOSITION.md` and marked `Verified`. A patch is not complete when its idea merely appears elsewhere in the document.

## P-001 — Correct release status

**Anchor:** document title and `Status of This Document`.

**Action:** Replace the pre-release `Status: Stable` label with `Status: Release Candidate 2` during hardening. Restore `Stable` only after the Release Witness Case and ratification record are complete.

**Required changelog statement:**

> Pre-release draft erroneously labelled `Stable`; the label was withdrawn before publication and superseded by `RC2`. The correction is preserved as a lifecycle record rather than silently mutated.

## P-002 — Strengthen Evaluation Profile definition

**Anchor:** `## 2.7. Evaluation Profile`, after the paragraph stating that authorization or structural validity does not establish warrant soundness.

**Insert conceptually:**

- Profile selection, authorship, authority, provenance, maintenance, effective interval, intended scope, and selection rule are material dependencies.
- A profile-comparison or translation rule is itself versioned, attributable, challengeable, and temporally bounded material.
- The Profile may require pre-commitment to a Profile or selection rule before inspection **by the selecting party**.
- Profile-controlled-by-evaluated-party is a disclosed dependency and potential conflict of interest, not automatic invalidity.

## P-003 — Add Terminal Premises and the Limits of Regress

**Anchor:** immediately after `## 2.9. Witness Case` and before `## 2.10. Support Envelope`.

**Required text:**

### Terminal Premises and the Limits of Regress

Witnessability does not eliminate the need for terminal premises, trust anchors, definitions, physical assumptions, normative authorities, or other irreducible starting conditions.

Its purpose is not to make every premise independently self-proving, but to prevent such premises from remaining hidden or from being represented as conclusions established by the Witness Case.

A terminal premise should identify, where material:

- a stable identifier or reference;
- its type;
- its source or authority;
- its scope;
- the reason it is treated as terminal;
- its uncertainty or contestability;
- its temporal applicability;
- the consequences of its rejection or failure.

Stable identity and cross-case referenceability should be sufficient to detect common terminal dependencies across different Witness Cases.

Meta-witnessing may relocate, refine, or challenge a terminal dependency, but it does not eliminate the need for an explicitly represented epistemic, physical, institutional, definitional, or normative stopping point.

## P-004 — Add Support for Normative Propositions

**Anchor:** after `## 2.1. Target Proposition` or as a dedicated subsection before Claim Assertion.

**Required text:**

### Support for Normative Propositions

For a normative Target Proposition, the Support Envelope should distinguish support for relevant factual premises from support for the validity, adoption, authority, applicability, or interpretation of the applicable normative premise.

Evidence that a rule was adopted, issued by an authorized institution, or applicable within a specified regime does not by itself establish that the rule is morally correct or universally valid.

A transition from factual premises to a normative conclusion requires an explicit normative warrant and the applicable normative premise, standard, or authority relation.

## P-005 — Add Evaluation Profile Governance and Abuse Resistance

**Anchor:** new subsection after current `§8.5 Abuse Resistance`.

**Required heading:** `## 8.6. Evaluation Profile Governance and Abuse Resistance`

**Required concepts:**

- The selection, authorship, authority, provenance, maintenance, effective interval, intended scope, and selection rule of an Evaluation Profile are material dependencies.
- Assessment under one Profile is not profile-neutral or equivalent to assessment under another absent an explicit comparison/translation rule.
- Selection after inspection by the selecting party is disclosed unless governed by a predeclared selection rule.
- Profile authorship/control by evaluated party is disclosed as dependency and potential COI.
- Authorization/adoption/syntactic validity does not establish soundness.
- Comparison/translation rules are versioned, attributable, challengeable, temporally bounded material.
- Profile-shopping, profile capture, undisclosed profile substitution, **undisclosed retrospective profile selection**, and presenting profile-relative results as profile-neutral are evaluation abuse.

## P-006 — Add Boundary Ceiling Rule

**Anchor:** new derived rule after `§6.4 Meta-Witnessing Rule` or before Non-Equivocation.

**Required text:**

### Boundary Ceiling Rule

Where support for a proposition depends on crossing an evidentially material boundary, interface, transition, or Binding Relation, no downstream Support Envelope may attribute preservation of a material property beyond what is established across that construct, unless an explicit preservation warrant or an independent additional basis licenses the stronger attribution.

This rule specializes the Non-Amplification invariant to material-property preservation across Witnessability boundary constructs.

## P-007 — Add formal-scope disclaimer

**Anchor:** immediately under `# 7. Abstract Formal Core`.

**Required text:**

> This section defines an abstract formal signature and a set of safety constraints. It is not a complete proof theory, denotational semantics, probabilistic semantics, or machine-checked formal foundation.

## P-008 — Empty-frontier semantics

**Anchor:** `§7.6 Maximal Licensed Frontier`, after the definition of the frontier.

**Required concepts:**

- The frontier may be empty.
- Distinguish:
  1. `licensed set is empty`; and
  2. `licensed set is nonempty but has no maximal equivalence class`.
- Assessment/Profile records which case applies.
- Approximation/closure/bounded-resolution/limit presentation applies only when defined by Profile and does not fabricate a maximum.

**Required formulas:**

\[
\mathcal F_{P,t}(K)=\varnothing
\]

with separately represented cause.

## P-009 — Warrant-bound composition and qualification inheritance

**Anchor:** replace/extend `§7.9 Composition`.

**Required notation:**

\[
K_c=K_1\oplus_{P,t}^{\,w}K_2
\]

\[
\mathcal L_{P,t}(K_c)
\subseteq
\operatorname{CompLic}_{P,t}(K_1,K_2,w)
\]

**Required safety constraints:**

- Any support beyond that independently licensed by the source Cases is traceable to `w` and required additional premises, bindings, dependencies, and preservation relations.
- `RequiredQualifications_{P,t}(K_c,e)` includes every unresolved source qualification material to `e`.
- A source qualification may be removed only through an explicit resolution represented in the Support Basis of the composition warrant.

## P-010 — Appendix A CC-1…CC-18

**Anchor:** append the controlled checklist from `APPENDIX-A-CONCEPTUAL-CONSISTENCY-CHECKLIST-DRAFT.md`.

**Critical verification points:**

- CC-9 says **ensure non-amplification / prohibit amplification**, never “prohibit non-amplification”.
- CC-2 lists the six-object minimal external conceptual interface.
- CC-17 preserves negative-claim discipline.
- CC-18 preserves independence/common-dependency discipline.

## P-011 — Alignment claim completeness

**Anchor:** `§9 Conformance Direction` and Appendix A.

**Required wording:**

> A claim of alignment with the Witnessability Conceptual Core is incomplete unless accompanied by a Conceptual Consistency Mapping.

The mapping includes applicability, justification for non-applicable items, known deviations, and all relevant versions.

## P-012 — Freeze language

**Anchor:** release ratification, not the conceptual body.

**Required rule:** The freeze statement is a governance decision under an identified release process. It is not a claim that the Core is complete, infallible, empirically proven, or immune to future counterexamples.

## Application status

Patches P-001 through P-012 were applied to `WITNESSABILITY-CORE-1.0-RC2-WORKING.md` and checked against the controlled anchors on 2026-07-24. The exact post-patch hash, line anchors, and critical transmission checks are recorded in `PATCH-VERIFICATION-REPORT.md`. P-012 is represented in the draft ratification artifacts and does not assign `Stable` status.
