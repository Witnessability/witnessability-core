# Witnessability Conceptual Core 1.0 — RC2 Ratification Package

## Purpose

This package is the controlled source of truth for ratifying the Witnessability Conceptual Core 1.0 release. The conceptual text is frozen and no longer under content revision.

The package preserves two distinct artifacts:

1. the anchor-verified RC2 frozen source;
2. the exact prospective Stable artifact, derived only by a declared status-block substitution.

This two-stage structure prevents the embedded lifecycle-status change from invalidating the hash of the artifact actually reviewed and frozen.

## Authoritative text artifacts

- Frozen source: `WITNESSABILITY-CORE-1.0-RC2-FROZEN.md` — `3120657dd39d81c07a29b314dfca3357235cd4a1c01da7f422c21917fbfbbd04`
- Stable candidate: `WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md` — `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`

The Stable candidate is not issued and carries no ratified status until `RATIFICATION-RECORD-DRAFT.md` is completed as an attributed governance decision. The selected Profile was amended after material inspection under a disclosed amendment and is now frozen before ratification evaluation.

## Core verification records

- `BYTE-IDENTITY-PRESERVATION-RECORD.md`
- `TEXT-FREEZE-RECORD.md`
- `STATUS-TRANSFORMATION-SPEC.yaml`
- `RC2-TO-STABLE-STATUS-DIFF.patch`
- `STATUS-TRANSFORMATION-VERIFICATION-REPORT.md`
- `STABLE-ISSUANCE-PLAN.md`
- `PATCH-VERIFICATION-REPORT.md`
- `REVIEW-DISPOSITION.md`

## Self-application artifacts

- `PROFILE-AMENDMENT-RECORD.md`
- `RELEASE-EVALUATION-PROFILE-RC2.yaml`
- `RELEASE-WITNESS-CASE-RC2.yaml`
- `RATIFICATION-RECORD-DRAFT.md`
- `REVIEW-SESSION-HASH-VERIFICATION-STATEMENT.md`
- `UNRESOLVED-LIMITATIONS.md`

## Release rule

After ratification, the published `WITNESSABILITY-CORE-1.0.md` must be byte-identical to `WITNESSABILITY-CORE-1.0-STABLE-CANDIDATE.md` and have SHA-256 `382e39864e257d93a0afd16c377c54f59a2182ecc5c38178764ded29ffb3f034`. Any content change requires a new release case and ratification.

## RS-02 integration revision

This package revision incorporates the reviewer-provided statement `urn:witnessability:review-statement:RS-02` and a reproducible verification procedure without changing the frozen Core, Stable candidate, selected Release Evaluation Profile, or pinned base Release Witness Case.

Because the integration order simultaneously required modification and pinned-hash preservation of the base Witness Case, the historical Case remains byte-identical and the new material is represented through:

- `RELEASE-WITNESS-CASE-RC2-RS02-SUPPLEMENT.yaml`;
- `REVIEWER-ATTRIBUTION-AND-QUALIFICATIONS.md`;
- `INCORPORATION-DELTA-SPEC.yaml`;
- `RS02-INTEGRATION-DISPOSITION.md`;
- `RS02-INTEGRATION-VERIFICATION-REPORT.md`;
- `verify-release.sh`.

RS-02 attests the source package identified by ZIP SHA-256 `72c66132fa086d6e2fd22fd3820ac91b314d60282d5bcee05e7e1d145ec9bdc7`. It does not attest this incorporating revision. The final manifest and canonical ZIP require an external attributed ratification attestation outside the certified ZIP.
